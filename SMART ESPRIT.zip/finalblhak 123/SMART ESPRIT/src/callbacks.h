#include <gtk/gtk.h>



void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_button19_e_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

//////////////////////////////////////////////////////////OMAR///////////////////////////////////////////////////////////////////

void
on_treeview_o_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_true_actualiser_o_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_o_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_menu_rechercher_o_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_ajouter_o_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_ok_o_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_supprimer_o_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_info_consulter_o_clicked     (GtkButton       *button,
                                        gpointer         user_data);

//////////////////////////////////////////////////////////OMAR///////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////WASSIM////////////////////////////////////////////////////
void
on_button_1_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_2_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_3_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_4_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_hebergement_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_af_w_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_w_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_w_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_w_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_w_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
//////////////////////////////////////////////////WASSIM////////////////////////////////////////////////////

////////////////////////////////////////////////HAMZA/////////////////////////////////////////////////////////

void
on_boutonAjouter_h_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobuttonPd_h_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDIN_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDEJ_h_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonModifier_h_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_h_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonMmenu_h_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonMj_h_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAj_h_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAutre_h_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAfficher_h_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimer_h_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifier_h_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonRecherche_h_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonOk_h_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton8_h_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton6_h_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_h_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_h_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_h_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAff_h_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAff_h_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_h_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_h_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_h_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonshow_h_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

              

///////////////////////////////////////////////////HAMZA////////////////////////////////////////////////////////


///////////////////////////////////////siwar//////////////////////////////////////////////////////

#include <gtk/gtk.h>


void
on_button1_stock_clicked               (GtkButton       *button,
                                        gpointer         user_data);



void
on_button5_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);


void
on_retour_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_image14_accel_closures_changed      (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_button4_rupture_clicked             (GtkButton       *button,
                                        gpointer         user_data);


void
on_button9_supprimer_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);



void
on_recherche_si_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_dialog_ajouter_produit_activate_default
                                        (GtkWindow       *window,
                                        gpointer         user_data);



void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);



void
on_home_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_affiche_rupture_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_retourner_rupture_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualiser_rupture_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_siwar_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview_rupture_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajout_si_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_radiobutton2_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_si_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifier_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_actualiser_si_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button11_si_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_button13_si_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);
void
on_button12_si_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);             
////////////////////////////////////////////siwar///////////////////////////////////////////////

///////////////////////////////////////rihem/////////////////////////////////////////////////////////
void
on_button_affichage_r_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_add_r_clicked                  (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_okk_r_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_returnadd_r_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_r_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_r_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_sup_r_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_returnsup_r_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modf_r_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button_returnmodif_r_clicked          (GtkButton       *button,
                                        gpointer         user_data);




void
on_button_aff_r_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_servicereclame_r_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_service_r_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_resultat_r_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1_r_toggled                (GtkToggleButton  *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_r_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_r_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_recherche_r_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_treeview1_r_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton1_r_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_r_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_r_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
///////////////////////////////////////rihem/////////////////////////////////////////////////////////







gboolean
on_label87_r_activate_link             (GtkLabel        *label,
                                        gchar           *arg1,
                                        gpointer         user_data);

void
on_button199_r_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_affiche3_r_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
